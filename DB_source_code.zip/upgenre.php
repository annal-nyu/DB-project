<?php
include "dbconn.php";

$sql = "update genres set type = ? where genre_id = ?";
$genre_id  =  $_REQUEST["genre_id"];
$type = $_REQUEST["type"];
$stmt = $conn->prepare($sql);

$stmt->bind_param("si", $type,$genre_id );
       
if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'genres.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>