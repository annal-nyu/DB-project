<?php
include "dbconn.php";

$sql = "insert into genres (type) VALUES (?)"; 


$txt = $_REQUEST["txt"];
$stmt = $conn->prepare($sql);

$stmt->bind_param("s", $txt);
if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'genres.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>




<?php
include "dbconn.php";

$sql = "insert into customers (firstname,lastname,email) VALUES (?,?,?)"; 

$fname = $_REQUEST["fname"];
$lname = $_REQUEST["lname"];
$email = $_REQUEST["email"];
$stmt = $conn->prepare($sql);

$stmt->bind_param("sss", $fname,$lname,$email);
if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'customers.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>