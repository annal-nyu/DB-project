<?php
include "dbconn.php";
include "menu.php";
echo "<table border=1><tr><th>Level</th><th>Unit Price ($)</th><th>Package Info</th></tr>";
$sql = "SELECT * FROM prices order by price_id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" . $row["price_id"] . "</td><td>" . $row["price"] . "</td><td>" . $row["info"] .
      "</td><td><a href='delprice.php?price_id=" . $row["price_id"] . "'>Delete</a></td>" .
      "</td><td><a href='editprice.php?price_id=" . $row["price_id"] . "'>Edit</a></td></tr>";
}  
echo "</table>";
$conn->close();
?>
<a href="addprice.htm">Add New</a>