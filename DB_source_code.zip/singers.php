<?php error_reporting(0); ?> 
<?php
include_once "dbconn.php";

$sid = $_REQUEST["sid"];
if(empty($sid))
{
  include "menu.php";
  $sql = "SELECT * FROM singers";
}
else
{
  $sql = "SELECT * FROM singers where sid =  $sid";
  
}

echo "<table border=1><tr><th>Artist #</th><th> Event Code</th><th>Artist Name</th><th>Genre id</th></tr>";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {

    echo "<tr><td>" . $row["sid"] . "</td><td>" . $row["event_code"] . "</td><td>" . $row["name"] .
      "</td><td>" . $row["gid"] . "</td><td><a href='delsinger.php?sid=" . $row["sid"] . "'>Delete</a></td>" .
      "</td><td><a href='editsinger.php?sid=" . $row["sid"] . "'>Edit</a></td></tr>";
  }
}  
echo "</table>";
$conn->close();
?>
<a href="addsinger.htm">Add New</a>