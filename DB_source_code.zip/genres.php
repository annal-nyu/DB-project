<?php
include "dbconn.php";
include "menu.php";
echo "<table border=1><th>Genre id</th><th>Type</th></tr>";
$sql = "SELECT * FROM genres";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" .$row["genre_id"] . "</td><td>". $row["type"] . "</td><td><a href='delgenre.php?genre_id=" . $row["genre_id"] . "'>Delete</a></td>" .
      "</td><td><a href='editgenre.php?genre_id=" . $row["genre_id"] . "'>Edit</a></td></tr>";
}  
echo "</table>";
$conn->close();
?>
<a href="addgenre.htm">Add New</a>

