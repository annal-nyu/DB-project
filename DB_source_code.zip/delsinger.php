<?php
include "dbconn.php";
$sql = "delete from singers where sid=?";
$sid = $_REQUEST["sid"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $sid);

if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'singers.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>