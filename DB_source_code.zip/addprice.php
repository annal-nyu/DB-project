<?php
include "dbconn.php";

$sql = "insert into prices VALUES (?,?,?)"; 

$level = $_REQUEST["level"];
$price = $_REQUEST["price"];
$info = $_REQUEST["info"];
$stmt = $conn->prepare($sql);

$stmt->bind_param("sss", $level,$price,$info);
if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'prices.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>