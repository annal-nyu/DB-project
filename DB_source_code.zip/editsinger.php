<?php
include "dbconn.php";
 
$sql = "SELECT * FROM singers where sid = ? ";
$sid = $_REQUEST["sid"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $sid);
$stmt->execute();
$result = $stmt->get_result();
 
if ($result->num_rows > 0) {
 $row = $result->fetch_assoc();
} 
 
?>
<form action="upsinger.php">
 <label for="event_code">Event Code:</label><br>
 <input type="text" id="event_code" name="event_code" value="<?php echo $row["event_code"]?>"><br>
 <label for="name">Artist Name:</label><br>
 <input type="text" id="name" name="name"  value="<?php echo $row["name"]?>"><br>
 <input type="hidden" id="sid" name="sid"  value="<?php echo $_REQUEST["sid"]?>"><br>
 <input type="submit" value="Submit">
</form>
<?php
$conn->close();
?>



