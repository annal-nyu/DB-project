<?php
include "dbconn.php";

$sql = "call buytickets(?,?,?,?,@status)"; 

$festival = $_REQUEST["festival"];
$customer = $_REQUEST["customer"];
$number = $_REQUEST["number"];
$level = $_REQUEST["level"];

$stmt = $conn->prepare($sql);

$stmt->bind_param("ssss", $festival,$customer,$number,$level);
if ($stmt->execute() === TRUE) {
  $sql = "SELECT @status as status";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  if($row["status"] == "OK")
    echo "Tickets Successfully Reserved - Thank you!";
  else
    echo $row["status"];  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
