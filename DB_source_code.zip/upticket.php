<?php
include "dbconn.php";
 
$sql = "update tickets set event_code = ?, number = ?, level= ? where tickid = ?";
$tickid =  $_REQUEST["tickid"];
$event_code = $_REQUEST["event_code"];
$number = $_REQUEST["number"];
$level = $_REQUEST["level"];
$stmt = $conn->prepare($sql);
 
$stmt->bind_param("sssi", $event_code,$number,$level,$tickid);
     
if ($stmt->execute() === TRUE) {
 echo "<script>window.location.href = 'tickets.php'</script>";
} else {
 echo "Error: " . $sql . "<br>" . $conn->error;
}
 
$conn->close();
?>
