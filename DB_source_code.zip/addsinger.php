<?php
include "dbconn.php";

$sql = "insert into singers (event_code,name,gid) VALUES (?,?,?)"; 


$event_code = $_REQUEST["event_code"];
$name = $_REQUEST["name"];
$gid = $_REQUEST["gid"];
$stmt = $conn->prepare($sql);

$stmt->bind_param("ssi", $event_code,$name,$gid);
if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'singers.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>