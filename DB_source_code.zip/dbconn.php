<?PHP

$servername = "localhost";
$username = "id18885022_myname";
$password = "6Ml6<YxU({5FK?*6";
$dbname = "id18885022_mydb";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>