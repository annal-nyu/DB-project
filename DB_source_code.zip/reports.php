<?php
include "dbconn.php";
include "menu.php";

echo "<p align='left'> <font color=blue  size='5pt'>The most popular events by attendance:</font> </p>";
echo "<table border=1><tr><th>Event Code</th><th>Event Name</th><th>Total Attendance</th></tr>";
$sql = "SELECT * FROM most_popular_event";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" . $row["event_code"] . "</td><td>" . $row["name"] . "</td><td>" . $row["total_attendance"] . "</td></tr>";
}  
echo "</table>";
$conn->close();
?>
<br>
<br>
<br>
<br>
<br>


<?php
include "dbconn.php";
echo "<p align='left'> <font color=blue  size='5pt'>Total revenue per event:</font> </p>";

echo "<table border=1><tr><th>Event Code</th><th>Total Tickets</th><th>Total Revenue</th></tr>";
$sql = "SELECT * FROM revenue_per_event";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" . $row["eventcode"] . "</td><td>" . $row["total_tickets"] . "</td><td>" . $row["total_revenue"] . "</td></tr>";
}  
echo "</table>";
$conn->close();
?>