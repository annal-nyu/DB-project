<?php
include "dbconn.php";
$sql = "delete from tickets where tickid=?";
$id = $_REQUEST["tickid"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'tickets.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>