<?php
include "dbconn.php";

$sql = "insert into festivals (code,name) VALUES (?,?)"; 

$code = $_REQUEST["code"];
$name = $_REQUEST["name"];
$stmt = $conn->prepare($sql);

$stmt->bind_param("ss", $code,$name);
if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'festivals.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>