<?php
include "dbconn.php";
include "menu.php";

echo "<p align='left'> <font color=blue  size='3pt'>Customers:</font> </p>";
echo "<table border=1><tr><th>First Name</th><th>Last Name</th><th>Email</th></tr>";
$sql = "SELECT * FROM customers";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" . $row["firstname"] . "</td><td>" . $row["lastname"] . "</td><td>" . $row["email"] .
      "</td><td><a href='delcustomer.php?id=" . $row["id"] . "'>Delete</a></td>" .
      "</td><td><a href='editcustomer.php?id=" . $row["id"] . "'>Edit</a></td></tr>";
}  
echo "</table>";
$conn->close();
?>
<a href="addcustomer.htm">Add New</a>