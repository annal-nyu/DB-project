<?php
include "dbconn.php";

$sql = "SELECT * FROM festivals where code = ? ";
$code = $_REQUEST["code"];

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
}  
?>
<form action="upfestival.php">
  <label for="code">Code:</label><br>
  <input type="text" id="code" name="code" readonly=True value="<?php echo $row["code"]?>"><br>
  <label for="name">Description:</label><br>
  <input type="text" id="name" name="name"  value="<?php echo $row["name"]?>"><br>
  <input type="hidden" id="code" name="code"  value="<?php echo $_REQUEST["code"]?>"><br>
  <input type="submit" value="Submit">
</form>
<?php
include "singers.php";
$conn->close();
?>