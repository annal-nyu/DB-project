<?php
include "dbconn.php";
 
$sql = "update singers set event_code = ?, name = ? where sid = ?";
$sid =  $_REQUEST["sid"];
$event_code = $_REQUEST["event_code"];
$name = $_REQUEST["name"];
$stmt = $conn->prepare($sql);
 
$stmt->bind_param("ssi", $event_code,$name,$sid);
     
if ($stmt->execute() === TRUE) {
 echo "<script>window.location.href = 'singers.php'</script>";
} else {
 echo "Error: " . $sql . "<br>" . $conn->error;
}
 
$conn->close();
?>


