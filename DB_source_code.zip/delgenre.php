<?php
include "dbconn.php";
$sql = "delete from genres where genre_id=?";
$genre_id= $_REQUEST["genre_id"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $genre_id);

if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'genres.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
