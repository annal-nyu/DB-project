<?php
include "dbconn.php";
include "menu.php";

echo "<table border=1><tr><th>Level</th><th>Unit Price ($)</th><th>Package Info</th></tr>";
$sql = "SELECT * FROM payments";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" . $row["price_id"] . "</td><td>" . $row["price"] . "</td><td>" . $row["info"]";   <tr><td>
}  
echo "</table>";
$conn->close();
?>
