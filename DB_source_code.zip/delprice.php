<?php
include "dbconn.php";
$sql = "delete from prices where price_id=?";
$price_id = $_REQUEST["price_id"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $price_id);

if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'prices.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>