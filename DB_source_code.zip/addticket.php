<?php
include "dbconn.php";
$sql = "SELECT * from festivals";
$result = $conn->query($sql);
$festivals = $result->fetch_all(MYSQLI_ASSOC);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
} 
?>
<form action="addticksvc.php">
  <label for="festival">Event Code:</label><br>
  <select id="festival" name="festival" >
      
<?php
  for($i=0;$i< count($festivals);$i++)
  {
    echo '<option value = "' . $festivals[$i]["code"];
    if($festivals[$i]["code"] == $row["event_code"])
      echo '"  selected>';
    else  
      echo '">';
    echo  $festivals[$i]["code"] . "</option>";
  }
?>
  </select></br>
  <label for="customer">Customer id:</label><br>
  <input type="text" id="customer" name="customer"><br>
  <label for="number">Number of Tickets:</label><br>
  <input type="text" id="number" name="number"><br>
  <label for="level">Package Level:</label><br>
  <input type="text" id="level" name="level"><br>

  <input type="submit" value="Submit">

</form>
<?php
include "festivals.php";
?>