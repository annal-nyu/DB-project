<?php
include "dbconn.php";

$sql = "SELECT * FROM prices where price_id = ? ";
$price_id = $_REQUEST["price_id"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $price_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
}  

?>
<form action="upprice.php">
  <label for="price_id">Level:</label><br>
  <input type="text" id="price_id" name="price_id" value="<?php echo $row["price_id"]?>"><br>
  <label for="price">Unit Price:</label><br>
  <input type="text" id="price" name="price"  value="<?php echo $row["price"]?>"><br>
  <label for="info">Package Info:</label><br>
  <input type="text" id="info" name="info"  value="<?php echo $row["info"]?>"><br>
  <input type="submit" value="Submit">
</form>
<?php
$conn->close();
?>
