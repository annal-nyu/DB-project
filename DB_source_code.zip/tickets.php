<?php error_reporting(0); ?> 
<?php
include_once "dbconn.php";



  include "menu.php";  
  $sql = "SELECT concat(C.firstname,' ',C.lastname) as Name, T.* FROM tickets T JOIN customers C on T.cust_id = C.id";


echo "<table border=1><tr><th>Customer Name</th><th>Event</th><th># of Tickets</th><th>Package Level</th></tr>";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
     echo "<tr><td>" . $row["Name"] . "</td><td>" . $row["event_code"] . "</td><td>". $row["number"] .
      "<td>" . $row["level"] . "</td></td><td><a href='delticket.php?tickid=" . $row["tickid"] . "'>Delete</a></td>" .
      "</td><td><a href='editticket.php?tickid=" . $row["tickid"] . "'>Edit</a></td></tr>";
  }
}  
echo "</table>";
$conn->close();
?>
<a href="addticket.php">Add New</a>


