<?php
include "dbconn.php";
include "menu.php";
echo "<p align='left'> <font color=blue  size='3pt'>Festivals:</font> </p>";
echo "<table border=1><th>Event Code</th><th>Festival Name</th></tr>";
$sql = "SELECT * FROM festivals";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" .$row["code"] . "</td><td>". $row["name"] . "</td><td><a href='delfestival.php?code=" . $row["code"] . "'>Delete</a></td>" .
      "</td><td><a href='editfestival.php?code=" . $row["code"] . "'>Edit</a></td></tr>";
}  
echo "</table>";
$conn->close();
?>
<a href="addfestival.htm">Add New</a>


