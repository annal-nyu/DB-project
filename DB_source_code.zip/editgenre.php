<?php
include "dbconn.php";

$sql = "SELECT * FROM genres where genre_id = ? ";
$genre_id = $_REQUEST["genre_id"];

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $genre_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
}  
?>
<form action="upgenre.php">
  <label for="genre_id">Code:</label><br>
  <input type="text" id="genre_id" name="genre_id" readonly=True value="<?php echo $row["genre_id"]?>"><br>
  <label for="name">Description:</label><br>
  <input type="text" id="type" name="type"  value="<?php echo $row["type"]?>"><br>

  <input type="submit" value="Submit">
</form>
<?php
include "genres.php";

?>