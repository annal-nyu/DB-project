<?php
include "dbconn.php";
 
$sql = "SELECT * FROM tickets where tickid = ? ";
$tickid = $_REQUEST["tickid"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tickid);
$stmt->execute();
$result = $stmt->get_result();
 
if ($result->num_rows > 0) {
 $row = $result->fetch_assoc();
} 
 
?>
<form action="upticket.php">

 <label for="event_code">Event Code:</label><br>
 <input type="text" id="event_code" name="event_code" value="<?php echo $row["event_code"]?>"><br>
 <label for="number">Number of Tickets:</label><br>
 <input type="text" id="number" name="number"  value="<?php echo $row["number"]?>"><br>
 <label for="level">Package Level:</label><br>
 <input type="text" id="level" name="level"  value="<?php echo $row["level"]?>"><br>
 
 <input type="hidden" id="tickid" name="tickid"  value="<?php echo $_REQUEST["tickid"]?>"><br>
 <input type="submit" value="Submit">
</form>
<?php
$conn->close();
?>
