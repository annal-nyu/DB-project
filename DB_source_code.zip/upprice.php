<?php
include "dbconn.php";

$sql = "update prices set price = ?, info = ? where price_id = ?";
$price_id=  $_REQUEST["price_id"];
$price = $_REQUEST["price"];
$info = $_REQUEST["info"];
$stmt = $conn->prepare($sql);

$stmt->bind_param("sss", $price,$info,$price_id);
       
if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'prices.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

