<?php

 echo <<<MENU
   <a href="customers.php">Customers</a>
   <a href="festivals.php">Festivals</a>
   <a href="singers.php">Artists</a>
   <a href="tickets.php">Tickets</a>
   <a href="prices.php">Pricing</a>
   <a href="billing.php">Billing</a>
   <a href="genres.php">Genres</a>
   <a href="reports.php">Reports</a>
   </br>
   </br>
MENU;
?>