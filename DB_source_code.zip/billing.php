<?php
include "dbconn.php";
include "menu.php";
echo "<p align='left'> <font color=blue  size='3pt'>Billing Transactions:</font> </p>";

echo "<table border=1><tr><th>Customer Name</th><th># of Tickets</th><th>Package Level</th><th>Unit Price</th><th>Total Price</th></tr>";
$sql = "SELECT * FROM billing";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc())
     echo "<tr><td>" . $row["customer_name"] . "</td><td>" . $row["tnumber"] . "</td><td>" . $row["level"] . "</td><td>" . $row["unit_price"] . "</td><td>" . $row["total_price"] . "</td></tr>";
}  
echo "</table>";
$conn->close();
?>
