<?php
include "dbconn.php";
$sql = "delete from festivals where code=?";
$code = $_REQUEST["code"];
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $code);

if ($stmt->execute() === TRUE) {
  echo "<script>window.location.href = 'festivals.php'</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>